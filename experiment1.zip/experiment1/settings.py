from os import environ

SESSION_CONFIGS = [
    dict(
        name='my_exp',
        num_demo_participants=2,
        app_sequence=['my_exp']
        ),
    ]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(
        real_world_currency_per_point=1.00,
        participation_fee=1.00,
        doc="",
        mturk_hit_settings=dict(
            keywords='bonus, study',
            title='Decision guidance to choose either AI or human forecast (takes about 20 min)',
            description='Choose AI or human adjusted forecasts given the information',
            frame_height=500,
            template='global/mturk_template.html',
            minutes_allotted_per_assignment=60,
            expiration_hours=7 * 24,
            grant_qualification_id='3SHVTVENCBDFPKH2UWJBYP9O64ZJSC',
            qualification_requirements=[
          # grant_qualification_id='YOUR_QUALIFICATION_ID_HERE', # to prevent retakes
#             {
#                'QualificationTypeId': "3AWO4KN9YO3JRSN25G0KTXS4AQW9I6",
#                'Comparator': "DoesNotExist",
#             },
#             {
#                'QualificationTypeId': "4AMO4KN9YO3JRSN25G0KTXS4AQW9I7",
#                'Comparator': "DoesNotExist",
#             },
             {
                'QualificationTypeId': "00000000000000000071",
                'Comparator': "EqualTo",
                'LocaleValues': [{'Country': "US"}]
             },
    # At least 100 HITs approved
             {
                'QualificationTypeId': "00000000000000000040",
                'Comparator': "GreaterThanOrEqualTo",
                'IntegerValues': [100]
             },
    # At least 95% of HITs approved
             {
                'QualificationTypeId': "000000000000000000L0",
                'Comparator': "GreaterThanOrEqualTo",
                'IntegerValues': [95]
             },
    # to prevent retakes
             {
                'QualificationTypeId': "3SHVTVENCBDFPKH2UWJBYP9O64ZJSC",
                'Comparator': "DoesNotExist",
             },
            ]
    #grant_qualification_id=
    #{
    #'QualificationTypeId': "YOUR_QUALIFICATION_ID_HERE",
    #'Comparator': "DoesNotExist",
    #},
                        )
)

PARTICIPANT_FIELDS = []
SESSION_FIELDS = []

# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = 'en'

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = 'USD'
USE_POINTS = False

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

DEMO_PAGE_INTRO_HTML = """ """

SECRET_KEY = '*************'

AWS_ACCESS_KEY_ID = environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = environ.get('AWS_SECRET_ACCESS_KEY')



