from otree.api import *

doc = """
the test experiment
"""


class Constants(BaseConstants):
    name_in_url = 'my_exp'
    players_per_group = None
    num_rounds = 1
    part_fee = 1.0
    completion_code = 'test2022'
    correct_IMC_0 = 'flower'

    correct_choice1 = 'Human'
    correct_choice2 = 'Human'
    correct_choice3 = 'AI'
    correct_choice4 = 'AI'
    correct_choice5 = 'AI'
    correct_choice6 = 'AI'
    correct_choice7 = 'Human'
    correct_choice8 = 'Human'
    correct_choice9 = 'AI'
    correct_choice10 = 'AI'
    correct_choice11 = 'Human'
    correct_choice12 = 'Human'
    correct_choice13 = 'AI'
    correct_choice14 = 'AI'
    correct_choice15 = 'AI'
    correct_choice16 = 'Human'
    correct_choice17 = 'Human'
    correct_choice18 = 'AI'
    correct_choice19 = 'AI'
    correct_choice20 = 'Human'
    correct_choice21 = 'AI'
    correct_choice22 = 'AI'
    correct_choice23 = 'Human'
    correct_choice24 = 'Human'
    correct_choice25 = 'Human'
    correct_choice26 = 'AI'
    correct_choice27 = 'Human'
    correct_choice28 = 'AI'
    correct_choice29 = 'Human'
    correct_choice30 = 'AI'
    correct_choice31 = 'Human'
    correct_choice32 = 'Human'
    correct_choice33 = 'Human'
    correct_choice34 = 'AI'
    correct_choice35 = 'AI'
    correct_choice36 = 'AI'
    correct_choice37 = 'AI'
    correct_choice38 = 'Human'
    correct_choice39 = 'AI'
    correct_choice40 = 'Human'
    correct_choice41 = 'Human'
    correct_choice42 = 'AI'
    correct_choice43 = 'Human'
    correct_choice44 = 'AI'
    correct_choice45 = 'AI'
    correct_choice46 = 'AI'
    correct_choice47 = 'AI'
    correct_choice48 = 'Human'
    correct_choice01 = 'AI'
    correct_choice02 = 'Human'
    correct_choice03 = 'Human'
    correct_choice04 = 'AI'
    correct_choice05 = 'AI'
    correct_choice06 = 'Human'
    correct_choice07 = 'Human'
    correct_choice08 = 'AI'


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


# widget=widgets.RadioSelectHorizontal
class Player(BasePlayer):
    Q1 = models.IntegerField(label='1. What is average demand?', min=0, max=30)
    Q2 = models.IntegerField(label='2. What is AI forecast?', min=0, max=30)
    Q3 = models.IntegerField(label='3. What is Human forecast?', min=0, max=30)
    Q4 = models.IntegerField(label='4. What is adjustment magnitude (without sign)?', min=0, max=30)
    Q5 = models.StringField(
        choices=[['Upward', 'Upward'], ['Downward', 'Downward']],
        label='5. Is the adjustment upward or downward?',
        widget=widgets.RadioSelect,
    )
    Q6 = models.StringField(
        choices=[['Small', 'Small'], ['Large', 'Large']],
        label='6. Is the adjustment small or large?',
        widget=widgets.RadioSelect,
    )
    Q7 = models.StringField(
        choices=[['AI forecast', 'AI forecast'], ['Human forecast', 'Human forecast']],
        label='7. If actual demand is 15, which forecast is more accurate, i.e., lower forecast error?',
        widget=widgets.RadioSelect,
    )
    Q8 = models.StringField(
        choices=[[1, '3'], [2, '17'], [3, '32'], [4, '10']],
        label='8. Which cannot indicate an actual demand?',
        widget=widgets.RadioSelect,
    )
    Q9 = models.FloatField(label='9. What is the improvement probability by choosing this human adjustment? i.e., the human forecast with this adjustment is better than the AI forecast in ? % of the cases.', min=0, max=100)
    PQ1 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ2 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ3 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ4 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    #PQ5 = models.IntegerField(
    #    widget=widgets.RadioSelect,
    #    choices=[-2, -1, 0, 1, 2]
    #)
    PQ6 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ7 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ8 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ9 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    PQ10 = models.IntegerField(
        widget=widgets.RadioSelect,
        choices=[-2, -1, 0, 1, 2]
    )
    IMC_0 = models.StringField(label="What is your occupation?")
    IMC = models.StringField(label="What is your favorite color?")
    age = models.IntegerField(label='What is your age?', min=18, max=100)
    gender = models.StringField(
        choices=[['Male', 'Male'], ['Female', 'Female'], ['Other', 'Other']],
        label='What is your gender?',
        widget=widgets.RadioSelect,
    )
    education = models.StringField(
        choices=[['High school', 'High school'], ['Bachelor', 'Bachelor'], ['Master', 'Master'],
                 ['PhD or higher', 'PhD or higher']],
        label='What is the highest degree or level of education you have completed?',
        widget=widgets.RadioSelect,
    )
    work_status = models.StringField(
        choices=[['Student', 'Student'], ['Working (part-time, full-time, self-employed)',
                                          'Working (part-time, full-time, self-employed)'],
                 ['Retired', 'Retired'], ['Other', 'Other']],
        label='What is your work status?',
        widget=widgets.RadioSelect,
    )
    comp_skill = models.StringField(
        choices=[['1', 'I have taken at least one college-level course in computer science.'],
                 ['2', 'I have a computer science or engineering degree.'],
                 ['3', 'I have programming experience.'],
                 ['4', 'I don’t have any of the educational or work experiences about computer science/ technology.'],
                 ],
        label='What is your knowledge of computer science/technology? (Select the most relevant option)',
        widget=widgets.RadioSelect,
    )
    forecasting_skill = models.StringField(
        choices=[['1', 'I have taken at least one college-level course about forecasting.'],
                 ['2', 'I have forecasting experience based on my education.'],
                 ['3', 'I have forecasting experience based on my job.'],
                 ['4', 'I don’t have any of the educational or work experiences about forecasting.'],
                 ],
        label='What is your knowledge of forecasting? (Select the most relevant option)',
        widget=widgets.RadioSelect,
    )
    similar_exp = models.StringField(
        choices=[['Not at all', 'Not at all'],
                 ['Only one', 'Only one'],
                 ['A few times', 'A few times'],
                 ['Several times', 'Several times'],
                 ['Many times', 'Many times']
                 ],
        label='Have you participated in a similar experiment before?',
        widget=widgets.RadioSelect,
    )

    choice_01 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_02 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_03 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_04 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_05 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_06 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_07 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_08 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )

    choice_1 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_2 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_3 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_4 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_5 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_6 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_7 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_8 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_9 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_10 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_11 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_12 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_13= models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_14 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_15 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_16 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_17 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_18 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_19 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_20 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_21 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_22 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_23 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_24 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_25 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_26 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_27 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_28 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_29 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_30 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_31 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_32 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_33 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_34 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_35 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_36 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_37 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_38 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_39 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_40 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_41 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_42 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_43 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_44= models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_45 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_46 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_47 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )
    choice_48 = models.StringField(
        choices=[['AI', ''], ['Human', '']],
        widget=widgets.RadioSelectHorizontal,
    )

    payoff_1 = models.FloatField()
    payoff_2 = models.FloatField()
    payoff_3 = models.FloatField()
    payoff_4 = models.FloatField()
    payoff_5 = models.FloatField()
    payoff_6 = models.FloatField()
    payoff_7 = models.FloatField()
    payoff_8 = models.FloatField()
    payoff_9 = models.FloatField()
    payoff_10 = models.FloatField()
    payoff_11 = models.FloatField()
    payoff_12 = models.FloatField()
    payoff_13 = models.FloatField()
    payoff_14 = models.FloatField()
    payoff_15 = models.FloatField()
    payoff_16 = models.FloatField()
    payoff_17 = models.FloatField()
    payoff_18 = models.FloatField()
    payoff_19 = models.FloatField()
    payoff_20 = models.FloatField()
    payoff_21 = models.FloatField()
    payoff_22 = models.FloatField()
    payoff_23 = models.FloatField()
    payoff_24 = models.FloatField()
    payoff_25 = models.FloatField()
    payoff_26 = models.FloatField()
    payoff_27 = models.FloatField()
    payoff_28 = models.FloatField()
    payoff_29 = models.FloatField()
    payoff_30 = models.FloatField()
    payoff_31 = models.FloatField()
    payoff_32 = models.FloatField()
    payoff_33 = models.FloatField()
    payoff_34 = models.FloatField()
    payoff_35 = models.FloatField()
    payoff_36 = models.FloatField()
    payoff_37 = models.FloatField()
    payoff_38 = models.FloatField()
    payoff_39 = models.FloatField()
    payoff_40 = models.FloatField()
    payoff_41 = models.FloatField()
    payoff_42 = models.FloatField()
    payoff_43 = models.FloatField()
    payoff_44 = models.FloatField()
    payoff_45 = models.FloatField()
    payoff_46 = models.FloatField()
    payoff_47 = models.FloatField()
    payoff_48 = models.FloatField()
    payoff_01 = models.FloatField()
    payoff_02 = models.FloatField()
    payoff_03 = models.FloatField()
    payoff_04 = models.FloatField()
    payoff_05 = models.FloatField()
    payoff_06 = models.FloatField()
    payoff_07 = models.FloatField()
    payoff_08 = models.FloatField()
    a = models.IntegerField()
    b = models.IntegerField()


# PAGES
class Page1(Page):


#    timeout_seconds = 10
    form_model = 'player'
    form_fields = ['choice_1', 'choice_2', 'choice_3', 'choice_4',
                   'choice_5', 'choice_6', 'choice_7', 'choice_8']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_1 == Constants.correct_choice1:
            player.payoff_1 = 2.0
            player.a = 0
            player.b = 1
        else:
            player.payoff_1 = 0.0
            player.a = 1
            player.b = 0

        if player.choice_2 == Constants.correct_choice2:
            player.payoff_2 = 2.0+ player.payoff_1
            player.a += 0
            player.b += 1
        else:
            player.payoff_2 = 0.0+ player.payoff_1
            player.a += 1
            player.b += 0

        if player.choice_3 == Constants.correct_choice3:
            player.payoff_3 = 1.0+ player.payoff_2
            player.a += 1
            player.b += 0
        else:
            player.payoff_3 = 0.0+ player.payoff_2
            player.a += 0
            player.b += 1

        if player.choice_4 == Constants.correct_choice4:
            player.payoff_4 = 8.0+ player.payoff_3
            player.a += 1
            player.b += 0
        else:
            player.payoff_4 = 0.0+ player.payoff_3
            player.a += 0
            player.b += 1

        if player.choice_5 == Constants.correct_choice5:
            player.payoff_5 = 1.0+ player.payoff_4
            player.a += 1
            player.b += 0
        else:
            player.payoff_5 = 0.0+ player.payoff_4
            player.a += 0
            player.b += 1

        if player.choice_6 == Constants.correct_choice6:
            player.payoff_6 = 6.0+ player.payoff_5
            player.a += 1
            player.b += 0
        else:
            player.payoff_6 = 0.0+ player.payoff_5
            player.a += 0
            player.b += 1

        if player.choice_7 == Constants.correct_choice7:
            player.payoff_7 = 8.0+ player.payoff_6
            player.a += 0
            player.b += 1
        else:
            player.payoff_7 = 0.0+ player.payoff_6
            player.a += 1
            player.b += 0

        if player.choice_8 == Constants.correct_choice8:
            player.payoff_8 = 9.0+ player.payoff_7
            player.a += 0
            player.b += 1
        else:
            player.payoff_8 = 0.0+ player.payoff_7
            player.a += 1
            player.b += 0


class Page9(Page):
    form_model = 'player'
    form_fields = ['choice_9', 'choice_10', 'choice_11', 'choice_12',
                   'choice_13', 'choice_14', 'choice_15', 'choice_16']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_9 == Constants.correct_choice9:
            player.payoff_9 = 4.0+ player.payoff_8
            player.a += 1
            player.b += 0
        else:
            player.payoff_9 = 0.0+ player.payoff_8
            player.a += 0
            player.b += 1

        if player.choice_10 == Constants.correct_choice10:
            player.payoff_10 = 8.0+ player.payoff_9
            player.a += 1
            player.b += 0
        else:
            player.payoff_10 = 0.0+ player.payoff_9
            player.a += 0
            player.b += 1

        if player.choice_11 == Constants.correct_choice11:
            player.payoff_11 = 3.0+ player.payoff_10
            player.a += 0
            player.b += 1
        else:
            player.payoff_11 = 0.0+ player.payoff_10
            player.a += 1
            player.b += 0

        if player.choice_12 == Constants.correct_choice12:
            player.payoff_12 = 2.0+ player.payoff_11
            player.a += 0
            player.b += 1
        else:
            player.payoff_12 = 0.0+ player.payoff_11
            player.a += 1
            player.b += 0

        if player.choice_13 == Constants.correct_choice13:
            player.payoff_13 = 3.0+ player.payoff_12
            player.a += 1
            player.b += 0
        else:
            player.payoff_13 = 0.0+ player.payoff_12
            player.a += 0
            player.b += 1

        if player.choice_14 == Constants.correct_choice14:
            player.payoff_14 = 7.0+ player.payoff_13
            player.a += 1
            player.b += 0
        else:
            player.payoff_14 = 0.0+ player.payoff_13
            player.a += 0
            player.b += 1

        if player.choice_15 == Constants.correct_choice15:
            player.payoff_15 = 1.0+ player.payoff_14
            player.a += 1
            player.b += 0
        else:
            player.payoff_15 = 0.0+ player.payoff_14
            player.a += 0
            player.b += 1

        if player.choice_16 == Constants.correct_choice16:
            player.payoff_16 = 1.0+ player.payoff_15
            player.a += 0
            player.b += 1
        else:
            player.payoff_16 = 0.0+ player.payoff_15
            player.a += 1
            player.b += 0


class Page17(Page):
    form_model = 'player'
    form_fields = ['choice_17', 'choice_18', 'choice_19', 'choice_20',
                   'choice_21', 'choice_22', 'choice_23', 'choice_24']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_17 == Constants.correct_choice17:
            player.payoff_17 = 3.0+ player.payoff_16
            player.a += 0
            player.b += 1
        else:
            player.payoff_17 = 0.0+ player.payoff_16
            player.a += 1
            player.b += 0

        if player.choice_18 == Constants.correct_choice18:
            player.payoff_18 = 2.0+ player.payoff_17
            player.a += 1
            player.b += 0
        else:
            player.payoff_18 = 0.0+ player.payoff_17
            player.a += 0
            player.b += 1

        if player.choice_19 == Constants.correct_choice19:
            player.payoff_19 = 4.0+ player.payoff_18
            player.a += 1
            player.b += 0
        else:
            player.payoff_19 = 0.0+ player.payoff_18
            player.a += 0
            player.b += 1

        if player.choice_20 == Constants.correct_choice20:
            player.payoff_20 = 3.0+ player.payoff_19
            player.a += 0
            player.b += 1
        else:
            player.payoff_20 = 0.0+ player.payoff_19
            player.a += 1
            player.b += 0

        if player.choice_21 == Constants.correct_choice21:
            player.payoff_21 = 9.0+ player.payoff_20
            player.a += 1
            player.b += 0
        else:
            player.payoff_21 = 0.0+ player.payoff_20
            player.a += 0
            player.b += 1

        if player.choice_22 == Constants.correct_choice22:
            player.payoff_22 = 3.0+ player.payoff_21
            player.a += 1
            player.b += 0
        else:
            player.payoff_22 = 0.0+ player.payoff_21
            player.a += 0
            player.b += 1

        if player.choice_23 == Constants.correct_choice23:
            player.payoff_23 = 7.0+ player.payoff_22
            player.a += 0
            player.b += 1
        else:
            player.payoff_23 = 0.0+ player.payoff_22
            player.a += 1
            player.b += 0

        if player.choice_24 == Constants.correct_choice24:
            player.payoff_24 = 9.0+ player.payoff_23
            player.a += 0
            player.b += 1
        else:
            player.payoff_24 = 0.0+ player.payoff_23
            player.a += 1
            player.b += 0


class Page25(Page):
    form_model = 'player'
    form_fields = ['choice_25', 'choice_26', 'choice_27', 'choice_28',
                   'choice_29', 'choice_30', 'choice_31', 'choice_32',
                   'IMC']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_25 == Constants.correct_choice25:
            player.payoff_25 = 2.0+ player.payoff_24
            player.a += 0
            player.b += 1
        else:
            player.payoff_25 = 0.0+ player.payoff_24
            player.a += 1
            player.b += 0

        if player.choice_26 == Constants.correct_choice26:
            player.payoff_26 = 5.0+ player.payoff_25
            player.a += 1
            player.b += 0
        else:
            player.payoff_26 = 0.0+ player.payoff_25
            player.a += 0
            player.b += 1

        if player.choice_27 == Constants.correct_choice27:
            player.payoff_27 = 8.0+ player.payoff_26
            player.a += 0
            player.b += 1
        else:
            player.payoff_27 = 0.0+ player.payoff_26
            player.a += 1
            player.b += 0

        if player.choice_28 == Constants.correct_choice28:
            player.payoff_28 = 1.0+ player.payoff_27
            player.a += 1
            player.b += 0
        else:
            player.payoff_28 = 0.0+ player.payoff_27
            player.a += 0
            player.b += 1

        if player.choice_29 == Constants.correct_choice29:
            player.payoff_29 = 1.0+ player.payoff_28
            player.a += 0
            player.b += 1
        else:
            player.payoff_29 = 0.0+ player.payoff_28
            player.a += 1
            player.b += 0

        if player.choice_30 == Constants.correct_choice30:
            player.payoff_30 = 2.0+ player.payoff_29
            player.a += 1
            player.b += 0
        else:
            player.payoff_30 = 0.0+ player.payoff_29
            player.a += 0
            player.b += 1

        if player.choice_31 == Constants.correct_choice31:
            player.payoff_31 = 1.0+ player.payoff_30
            player.a += 0
            player.b += 1
        else:
            player.payoff_31 = 0.0+ player.payoff_30
            player.a += 1
            player.b += 0

        if player.choice_32 == Constants.correct_choice32:
            player.payoff_32 = 6.0+ player.payoff_31
            player.a += 0
            player.b += 1
        else:
            player.payoff_32 = 0.0+ player.payoff_31
            player.a += 1
            player.b += 0


class Page33(Page):
    form_model = 'player'
    form_fields = ['choice_33', 'choice_34', 'choice_35', 'choice_36',
                   'choice_37', 'choice_38', 'choice_39', 'choice_40']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_33 == Constants.correct_choice33:
            player.payoff_33 = 2.0+ player.payoff_32
            player.a += 0
            player.b += 1
        else:
            player.payoff_33 = 0.0+ player.payoff_32
            player.a += 1
            player.b += 0

        if player.choice_34 == Constants.correct_choice34:
            player.payoff_34 = 2.0+ player.payoff_33
            player.a += 1
            player.b += 0
        else:
            player.payoff_34 = 0.0+ player.payoff_33
            player.a += 0
            player.b += 1

        if player.choice_35 == Constants.correct_choice35:
            player.payoff_35 = 4.0+ player.payoff_34
            player.a += 1
            player.b += 0
        else:
            player.payoff_35 = 0.0+ player.payoff_34
            player.a += 0
            player.b += 1

        if player.choice_36 == Constants.correct_choice36:
            player.payoff_36 = 7.0+ player.payoff_35
            player.a += 1
            player.b += 0
        else:
            player.payoff_36 = 0.0+ player.payoff_35
            player.a += 0
            player.b += 1

        if player.choice_37 == Constants.correct_choice37:
            player.payoff_37 = 9.0+ player.payoff_36
            player.a += 1
            player.b += 0
        else:
            player.payoff_37 = 0.0+ player.payoff_36
            player.a += 0
            player.b += 1

        if player.choice_38 == Constants.correct_choice38:
            player.payoff_38 = 8.0+ player.payoff_37
            player.a += 0
            player.b += 1
        else:
            player.payoff_38 = 0.0+ player.payoff_37
            player.a += 1
            player.b += 0

        if player.choice_39 == Constants.correct_choice39:
            player.payoff_39 = 3.0+ player.payoff_38
            player.a += 1
            player.b += 0
        else:
            player.payoff_39 = 0.0+ player.payoff_38
            player.a += 0
            player.b += 1

        if player.choice_40 == Constants.correct_choice40:
            player.payoff_40 = 3.0+ player.payoff_39
            player.a += 0
            player.b += 1
        else:
            player.payoff_40 = 0.0+ player.payoff_39
            player.a += 1
            player.b += 0


class Page41(Page):
    form_model = 'player'
    form_fields = ['choice_41', 'choice_42', 'choice_43', 'choice_44',
                   'choice_45', 'choice_46', 'choice_47', 'choice_48']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant
        if player.choice_41 == Constants.correct_choice41:
            player.payoff_41 = 6.0+ player.payoff_40
            player.a += 0
            player.b += 1
        else:
            player.payoff_41 = 0.0+ player.payoff_40
            player.a += 1
            player.b += 0

        if player.choice_42 == Constants.correct_choice42:
            player.payoff_42 = 1.0+ player.payoff_41
            player.a += 1
            player.b += 0
        else:
            player.payoff_42 = 0.0+ player.payoff_41
            player.a += 0
            player.b += 1

        if player.choice_43 == Constants.correct_choice43:
            player.payoff_43 = 3.0+ player.payoff_42
            player.a += 0
            player.b += 1
        else:
            player.payoff_43 = 0.0+ player.payoff_42
            player.a += 1
            player.b += 0

        if player.choice_44 == Constants.correct_choice44:
            player.payoff_44 = 1.0+ player.payoff_43
            player.a += 1
            player.b += 0
        else:
            player.payoff_44 = 0.0+ player.payoff_43
            player.a += 0
            player.b += 1

        if player.choice_45 == Constants.correct_choice45:
            player.payoff_45 = 6.0+ player.payoff_44
            player.a += 1
            player.b += 0
        else:
            player.payoff_45 = 0.0+ player.payoff_44
            player.a += 0
            player.b += 1

        if player.choice_46 == Constants.correct_choice46:
            player.payoff_46 = 4.0+ player.payoff_45
            player.a += 1
            player.b += 0
        else:
            player.payoff_46 = 0.0+ player.payoff_45
            player.a += 0
            player.b += 1

        if player.choice_47 == Constants.correct_choice47:
            player.payoff_47 = 4.0+ player.payoff_46
            player.a += 1
            player.b += 0
        else:
            player.payoff_47 = 0.0+ player.payoff_46
            player.a += 0
            player.b += 1

        if player.choice_48 == Constants.correct_choice48:
            player.payoff_48 = 8.0+ player.payoff_47
            player.a += 0
            player.b += 1
        else:
            player.payoff_48 = 0.0+ player.payoff_47
            player.a += 1
            player.b += 0
        player.payoff = (player.payoff_48)/50.0


# class ResultsWaitPage(WaitPage):
#    pass


class Postexp1(Page):
    form_model = 'player'
    form_fields = ['PQ1', 'PQ2', 'PQ3']
    pass


class Postexp2(Page):
    form_model = 'player'
    form_fields = ['PQ4']
    pass


class Postexp3(Page):
    form_model = 'player'
    form_fields = ['PQ5']
    pass


class Postexp4(Page):
    form_model = 'player'
    form_fields = ['PQ6']
    pass


class Postexp5(Page):
    form_model = 'player'
    form_fields = ['PQ7', 'PQ8']
    pass


class Postexp6(Page):
    form_model = 'player'
    form_fields = ['PQ9']
    pass


class Postexp7(Page):
    form_model = 'player'
    form_fields = ['PQ10']
    pass


class Demographics(Page):
    form_model = 'player'
    form_fields = ['age', 'gender', 'education', 'work_status']
    pass


class Demographics2(Page):
    form_model = 'player'
    form_fields = ['comp_skill']
    pass


class Demographics3(Page):
    form_model = 'player'
    form_fields = ['forecasting_skill']
    pass


class Demographics4(Page):
    form_model = 'player'
    form_fields = ['similar_exp']
    pass


class Pretest(Page):
    form_model = 'player'
    form_fields = ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def error_message(player, values):
        print('values is', values)
        if values['Q1'] != 10:
            return 'The first answer is wrong'
        if values['Q2'] != 17:
            return 'The second answer is wrong'
        if values['Q3'] != 11:
            return 'The third answer is wrong'
        if values['Q4'] != 6:
            return 'The forth answer is wrong'
        if values['Q5'] != 'Downward':
            return 'The fifth answer is wrong'
        if values['Q6'] != 'Large':
            return 'The sixth answer is wrong'
        if values['Q7'] != 'AI forecast':
            return 'The seventh answer is wrong'
        if values['Q8'] != '3':
            return 'The eighth answer is wrong'
        if player.id_in_group % 2 == 0 and values['Q9'] != 70:
            return 'The ninth answer is wrong'
        elif player.id_in_group % 2 == 1 and values['Q9'] != 60:
            return 'The ninth answer is wrong'
    pass


class Test01(Page):
    form_model = 'player'
    form_fields = ['choice_01', 'choice_02', 'choice_03', 'choice_04',
                   'choice_05', 'choice_06', 'choice_07', 'choice_08']

    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )

    def before_next_page(player: Player, timeout_happened):
        participant = player.participant,
        if player.choice_01 == Constants.correct_choice01:
            player.payoff_01 = 6.0
            player.a = 1
            player.b = 0
        else:
            player.payoff_01 = 0.0
            player.a = 0
            player.b = 1

        if player.choice_02 == Constants.correct_choice02:
            player.payoff_02 = 3.0+ player.payoff_01
            player.a += 0
            player.b += 1
        else:
            player.payoff_02 = 0.0+ player.payoff_01
            player.a += 1
            player.b += 0

        if player.choice_03 == Constants.correct_choice03:
            player.payoff_03 = 2.0 + player.payoff_02
            player.a += 0
            player.b += 1
        else:
            player.payoff_03 = 0.0 + player.payoff_02
            player.a += 1
            player.b += 0

        if player.choice_04 == Constants.correct_choice04:
            player.payoff_04 = 2.0 + player.payoff_03
            player.a += 1
            player.b += 0
        else:
            player.payoff_04 = 0.0 + player.payoff_03
            player.a += 0
            player.b += 1

        if player.choice_05 == Constants.correct_choice05:
            player.payoff_05 = 3.0 + player.payoff_04
            player.a += 1
            player.b += 0
        else:
            player.payoff_05 = 0.0 + player.payoff_04
            player.a += 0
            player.b += 1

        if player.choice_06 == Constants.correct_choice06:
            player.payoff_06 = 5.0 + player.payoff_05
            player.a += 0
            player.b += 1
        else:
            player.payoff_06 = 0.0 + player.payoff_05
            player.a += 1
            player.b += 0

        if player.choice_07 == Constants.correct_choice07:
            player.payoff_07 = 2.0 + player.payoff_06
            player.a += 0
            player.b += 1
        else:
            player.payoff_07 = 0.0 + player.payoff_06
            player.a += 1
            player.b += 0

        if player.choice_08 == Constants.correct_choice08:
            player.payoff_08 = 1.0 + player.payoff_07
            player.a += 1
            player.b += 0
        else:
            player.payoff_08 = 0.0 + player.payoff_07
            player.a += 0
            player.b += 1


class Feedback1(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 8)*100
        return dict(
            aa=round(aa),
            bb=round(100-aa),
        )
    pass


class Results0(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 8) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results2(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 16) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results4(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 24) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results6(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 32) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results8(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 40) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results10(Page):
    @staticmethod
    def vars_for_template(player):
        aa = (player.a / 48) * 100
        return dict(
            aa=round(aa),
            bb=round(100 - aa),
        )
    pass


class Results(Page):
    @staticmethod
    def vars_for_template(player):
        tp = player.payoff + Constants.part_fee
        return dict(
            tp=tp
        )
    pass


class Instruction1(Page):
    pass


class Instruction2(Page):
    pass


class Instruction3(Page):
    @staticmethod
    def vars_for_template(player):
        pid = player.id_in_group % 2
        return dict(
            pid=round(pid),
        )
    pass


class Payment(Page):
    pass


class Pagephoto(Page):
    form_model = 'player'
    form_fields = ['choice_3']
    pass


class Instruction_add(Page):
    form_model = 'player'
    form_fields = ['IMC_0']
    pass


class Remove(Page):
    pass


page_sequence =[Instruction1, Instruction_add, Remove, Instruction2, Instruction3, Payment,
                 Pretest, Test01, Feedback1,
                 Page1, Results0, Page9, Results2,
                 Page17, Results4, Page25, Results6,
                 Page33, Results8, Page41, Results10,
                 Postexp1, Postexp2, Postexp4,
                 Postexp5, Postexp6, Postexp7,
                 Demographics, Demographics2, Demographics3, Demographics4,
                 Results]